package com.example.entity.dao.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.entity.Student;
import com.example.entity.dao.StudentRepository;
import com.example.entity.dto.Studentdto;


@Service
public class StudentService {
	
	
	@Autowired
	StudentRepository studentRepository;
	
	public void saveStudent(Studentdto studentdto)
	{
		studentRepository.save(studentdtotoStudent(studentdto));
	}
	
	 public List<Studentdto> getAllStudent(){

	        List<Student> listStudent= this.studentRepository.findAll();

	

    List<Studentdto> studentDtoList = listStudent.stream().map(emp -> this.studenttostudentdto(emp)).collect(Collectors.toList());
	return studentDtoList;

	 }	
	
	
	
	 public void deleteStudent(int empId){

	       studentRepository.deleteById(empId);

	    }
	    public Studentdto updateStudent(Studentdto studentdto)
	    {
	    studentRepository.save(studentdtotoStudent(studentdto));
	    return studentdto;

	    }
	
	
	
	 public Student studentdtotoStudent(Studentdto studentdto)
	    {
	        Student student=new Student();

	        student.setStudent_id(studentdto.getStudent_id());
	        student.setStudent_name(studentdto.getStudent_name());
	        student.setStudent_address(studentdto.getStudent_address());
	        student.setStudent_city(studentdto.getStudent_city());
	        student.setStudent_fees(studentdto.getStudent_fees());
	        

	       
	        return student;
	    }

	    public Studentdto studenttostudentdto(Student student)
	    {
	        Studentdto studentdto= new Studentdto();

	      studentdto.setStudent_id(student.getStudent_id());
	      studentdto.setStudent_name(student.getStudent_name());
	      studentdto.setStudent_address(student.getStudent_address());
	      studentdto.setStudent_city(student.getStudent_city());
	      studentdto.setStudent_fees(student.getStudent_fees());
	      
	      
	        return studentdto;
	    }
	
	
	

}
