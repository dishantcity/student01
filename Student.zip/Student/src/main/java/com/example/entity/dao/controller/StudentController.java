package com.example.entity.dao.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.dao.service.StudentService;
import com.example.entity.dto.Studentdto;



@RestController
public class StudentController {
	
	
	@Autowired
	StudentService studentService;
	
	
	@PostMapping("/student")
	public ResponseEntity<Studentdto> saveDep(@RequestBody Studentdto studentdto){
		studentService.saveStudent(studentdto);
		
		return new ResponseEntity<>(studentdto,HttpStatus.CREATED);
		
	}

	    @DeleteMapping("/student/{studentId}")
	    public void deleteAllo(@PathVariable("studentId") int id){
	      
	    	
	    	studentService.deleteStudent(id);
	    }
	    
	    @GetMapping("/student")
	    public ResponseEntity<List<Studentdto>> getStudent()
	    {
	        List<Studentdto> allStudent = studentService.getAllStudent();


	        return ResponseEntity.of(Optional.of(allStudent));

	     
	    }
	  
	  


	    @PutMapping("/student")
	    public ResponseEntity<Studentdto> updateall(@RequestBody Studentdto studentdto)
	    {
	       studentService.updateStudent(studentdto);
	        return new ResponseEntity<>(studentdto, HttpStatus.ACCEPTED);
	    }

	
	

}
