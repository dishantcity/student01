package com.example.entity.dto;

import javax.persistence.Id;

public class Studentdto {
	
	@Id
	private int student_id;
	private String student_name;
	private String student_address;
	private String student_city;
	private int student_fees;
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getStudent_address() {
		return student_address;
	}
	public void setStudent_address(String student_address) {
		this.student_address = student_address;
	}
	public String getStudent_city() {
		return student_city;
	}
	public void setStudent_city(String student_city) {
		this.student_city = student_city;
	}
	public int getStudent_fees() {
		return student_fees;
	}
	public void setStudent_fees(int student_fees) {
		this.student_fees = student_fees;
	}
	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", student_name=" + student_name + ", student_address="
				+ student_address + ", student_city=" + student_city + ", student_fees=" + student_fees + "]";
	}

}
